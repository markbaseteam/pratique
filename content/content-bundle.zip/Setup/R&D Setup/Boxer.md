Few Theories on the Boxer Setup:

If there is certain periode of time that separates each attempt of going throught the S/R.
1rst attempt stop a the limit of the box 
2nd grind it a little bit
3rd goes throught directly or never make it to its target by going side-way
- - -
## 1rst Entry:
##### Entry level:
* Below the Boxer's Box or at is low
##### Entry methode:
* SFP
* 1rst 
##### Early Closing:
* Early closing should be considered when there is no strong direct reaction. For the 1rst entry, almost all winning trade are already long gone after 3bars.
- - -
- - - 
## 2nd Entry:
* For a second entry to be considered, a strong rejection must have been observered on the 1st one.
	* This topic needs some study but to strat, we could consider a 0.5fib retranchement beeing a good start.
	* Of course, the time beeing the best mesure to note the power of the reaction.
- - -
- - -
## 3rd Entry:

- - -
- - - 
## Notes: 
- Does an area that have shown weak reaction tends to show a strong one when the price goes back to it but from the other side
	- It could could also be interpreted as an overall strong trend
	- Price does need to have range a bit inside it before