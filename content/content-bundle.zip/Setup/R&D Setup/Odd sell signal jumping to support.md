#### Infos:
- TimeFrame: 1h
- Asset: BTCUSD
- Direction: Long
#### Observations:
* I tend 
#### Théorie:
#### Research:
#### NOTES: