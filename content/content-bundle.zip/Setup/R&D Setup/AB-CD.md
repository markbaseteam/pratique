#### Infos:
- TimeFrame: 15min/1h
- Asset: BTCUSD/Forex
- Direction: Mainly Long
#### Observations:
* Price tends to consolidate above the 50ema ribbon before reaching new highs
* At this point, there seems to be 2 different setup possible:
	* (1) - Buying the lows of this new range
				Locations: 0.33-0.66 fib
	* (2) - Buying the breakout
#### Research:
* Goals:
1:
#### NOTES:
Does the probability of continuation can be influence by those factors?:
Price went bellow all baselines
Grey candle

### AB/CD Ratios:
 | C Point Retracement | BC Projection |
 | ------------------- | ------------- |
 | 0.382               | 0.24 /2.618   |
 | 0.5                 | 2             |
 | 0.618               | 1.618         |
 | 0.707               | 1.14          |
 | 0.786               | 1.27          |
 | 0.886               | 1.13          |
^d7efba

 