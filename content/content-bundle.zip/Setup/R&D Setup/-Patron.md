#### 0.Infos:
- TimeFrame:
- Asset: 
- Direction: 
#### 1.Observations:
#### 2.Théorie:
#### 3.Research:
- - -
- - -
# Variation 1:
### 1.The Entry:
- - -
### 2.The Objectif:
 - - -
### 3.The Management:
- - -
#### NOTES:
- - -
- - -