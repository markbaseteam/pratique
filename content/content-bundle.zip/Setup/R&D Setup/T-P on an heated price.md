### Notes on the Heat indicator:
--- 
#### Preamble: 
- When the price is "heated", it tends to ignore all TP signals and Resistance levels 