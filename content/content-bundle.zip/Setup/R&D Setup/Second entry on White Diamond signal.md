#### Infos on the observations:

- TimeFrame: mainly 15min but seems to work on others

#### Observations:

- Premise:
    - When a White Diamond doesn't play right away (2-3 candles sideways), it tends to go two ways:
        1: Go up
        2:Quick bull spike and trend does reverse the next candle with usually at least a pyramid on a grey candle and regularly complemented with bearish signals
- Cases of patterns/trendline breakout:

#### Research:
![[Second Entry Short.png]]
- Goals:
    - 1:

#### Setup:

#### Bunch of ideas:

- Cut the trade and look for an other entry if 2ITP occurred in the next3/4 candles after the signal