[[Trading]]
# Title: Waves  Key Level
- - -
#### Meta:
- Infos:
	- Type : Classic
	- TimeFrame: Drawing Wave: 1h+ // Entry: 5min+
	- Asset:  Btc + (Forex : used only as an indicator of S/R to legitimate Mag7)
	- Direction: Any
- Observations:
	-  Price tends to reverse on key level drawn with Volume profile and fibs.
	* Entry seems to be done on mom weakening or Divs 
## Théorie:
* A box is drawn between two keys fibs levels and can be adjusted with levels from the VP.![[BTCUSD_2022-03-26_14-40-54.png]]![[BTCUSD_2022-03-26_15-20-50.png]]
#### Key Notes:
- On the case of a Flat, Look for min 0.618 pref 1.23
- No Position if the price ripe through the box 
## Practice:
### The Entry:
#### 1st Type: Div Catcher 🔴
![[Div Catcher]]
#### 2nd Type: Mag 5 🟠
#### 3rd Type: Mag 7 🟢
![[Mag 7 Setup]]
### The Exit:
#### 1st Type: 

### The Management:
#### 1st Script:

- - -
### DLC:
+Linked Pages:
[[Notes Wave Key Level|Notes]]
[[R&D Wave Key Level]]
#trading/setups
Setup Type:: Active