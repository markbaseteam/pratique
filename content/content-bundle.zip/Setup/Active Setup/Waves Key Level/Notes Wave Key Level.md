[[Theory Wave Key Level]]
- - -
- Seems like letting limit orders on the blue box with SL like 0.2 below it can be money making
- Same for letting limits order on the second box if the first one haven't shown reaction.
- On the case of a Flat, Look for min0.618 pref 1.23
- Don't take position if the price is literally piercing through my Box (talking about 0 red Candle)  
- Sees like adding a confirmation like (In accordance of  Eliot projection) gives good results
	- It seems to also explain why levels aren't responding 
- Two times I see I see a red candle forming just above a box (meaning the box has been pierced), then the price consolidate a bit before making it's way the it's next and last one.
- Seems like when the box is roughly the same whether if  the T-B Fib 1st point is at a (0) or (2), it gives good results 
- The 1st to TPs are made to assure profit in any situation, the Rest is up to the configuration.
	- For expl, if you are in a Top Flash Crash Setup, you might want to delay your tp to maybe reach a (3)
### Box Note:
#### Positive:
- Fib of 0.618 and 0.5
- Confluence of S/R (seems they are generally at the top or above the box )
- Above Large Contradictory Arma Ribbon
#### Alternative Drawings:
- In situation where one of the Fib retracement is hard to draw / seems incorrect, it's possible to replace it with a diff fib expl:
- ![[BTCUSD_2022-04-12_10-20-45.png]]
### Entry:
#### Generals Rules
- As a general rule, there isn't suppose to be some pending limit order and a box is cancel when the price ripe it through 
- We can divide it by 3 phase, Top catcher, 1st Mom weakening and Mag7
#### R&D:
- Can you enter on a 
#### {1} - Top/Div Catcher:
- Div Catcher, with the 0 put on the first weakening (must have touch or be really close with the box)
	- Interdiction of moving SL 
	- Remember, Div Catcher is made to catch DIVS so if no div no setup.
	- Entry on the Red Arrow Bellow
![[BTCUSD_2022-03-25_09-24-31.png]]
#### {2} - Mom Weakening:
- Basically, it's a Mag 7 that's full of shit. 
	- LTTF Without crack
	- RSI/MFI Still above 60 
	- the C-bar is empty but not at the right place, etc
- SL
	- Should it be like a mag 7 or at the top
#### {3} - Mag 7:
### Exit:
#### 1st TP At Arma ribbon🟥
- Theoretically between 0.236 and 0.382 but can be a bit higher if Mom shows great strength  
- With the {1} entry, we can take a ≈40% TP at the 50 Ema ribbon or other first sign of medium S/R
	- Start by drawing a box on the zone of TP
	- 2 Possibilities for Exit:
		- 1: Pending Limit orders
			- Cool at first but you should maybe also have some C-Bet Orders in case the price goes completely away when you aren't around 
#### TP with a Mag 7.
- needs proper investigation but it seems like a lot of them goes to forming a (2) so quick tp are needed on weakening mom 
### Irregularities:
- For the Box:
	- an entry can be correct even if she isn't perfectly in the box (price didn't even touched it or above it) if:
		- Confluence of Setups (expl: Top Flash Crash/ 5th Wave Reversal/ Boxer|Strong S/R / Etc)
- - - 
- - - 
- - - -
## Exit Strat with the Wave Key Level Setup:
- Let's summarise a bit all the infos I can think of on this topic.
1st I want to avoid stats that would be some weird Eliot waves projections.
There is a need to have 
- A question is, do I want to have some quick TP on the 1st/2nd entry to reenter with a mag 7?
#### How can I have systematic rules of TP?
1. Fib Projections
	- Basically it's just reenacting the setup but in a TP way.
2. Mag 7/ Mom weakening
	- The thing is that it might make troubles when choosing the correct TF.

#### Observations:
- The Higher the TF, the closest the box you want to take TP at.