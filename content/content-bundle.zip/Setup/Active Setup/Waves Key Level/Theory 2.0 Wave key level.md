[[Trading]]
# Title: Waves Key Level
- - -
#### Meta:
- Infos:
	- Type :Classic
	- TimeFrame: 15min+ 
	- Asset: BTCUSD
	- Direction: "Any" a preference of short 
- Observations:
	- Fast (1), low vol(2),Fast (3), low vol(4), the (5) div
## Théorie:
#### Key Notes:

1. The location of the presumed (5th) Wave, must 
## Practice:
### The Entry:
#### 1st Type:
#### 2nd Type:

### The Exit:
#### 1st Type:

### The Management:
#### 1st Script:
- - -
+[[Notes 5th Wave reversal]]