[[Trading]]
# Title: _R&D Wave Key Level_
- - -
### General Stats:
- Calculating the probability for a Box to be the right one :
	- By it's number
	- Confluence
	- Just passed a good one
