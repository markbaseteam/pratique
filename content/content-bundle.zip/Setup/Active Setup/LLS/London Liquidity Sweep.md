# Title: London Liquidity Sweep
- - -
>[!toc]
>[/TOC/]

> [!info] Meta
> - Type : Entry /  Classic
> - TimeFrame:
> - Asset:
> - Direction:
> - Tags: #9/Theory #0/moc #5
> - Type::
- - -

## 📋  Theory
#### Key Notes:

## 🕹 Practice:
### The Entry:
#### 1st Type:
#### 2nd Type:

### The Exit:
#### 1st Type:

### The Management:
The trade should work (TP2 taken) in **max** 45’ and in extreme cases 1h
#### 1st Script:

