# Title: Me Type 1
- - -
#### Meta:
- Infos:
	- Type : Entry /  Classic
	- TimeFrame:
	- Asset:
	- Direction:
- Observations:
	- 
## Théorie:
#### Key Notes:

## Practice:
### The Entry:
#### 1st Type:
#### 2nd Type:

### The Exit:
#### 1st Type:

### The Management:
#### 1st Script:

- - -
+Linked Pages:
[[Basics Stats]]
[[Custom Stats]]

#trading/setups
Setup Type:: R&D