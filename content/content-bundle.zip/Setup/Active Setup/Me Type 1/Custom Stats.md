#### Signal:

- POD in the last 4 candles
- Diamond (old)
- Diamond (new)
- Yellow X
- Red Dot
- Close above 50Ema

#### Localisation / Mom (Signal + Box):
- Div

#### Localisation (Support) (Entry):
* White MA
* 200 MA
* EQ 3

#### Others:

- Atr multiple (Signal + Entry)
- Time between signal and entry
- Note (1-5)
- Max distance from price to box
- Confluence of same direction setup

#### Take-Profit :

- (High / Low of box)
- First Ma/ Baseline
- First Stack of MA / Baseline
- First Res (baseline or CPR/DSR)
- Yellow Flag

#### ENTRY STRAT:

- Ladder classic
- Single entry Classic
- Boxer 1rst entry
- Boxer 2nd Entry

#### Stop-Loss:

- Bellow/Above Nerest Daily Fib
- Bellow/Above nearest DSR

#### Second Entry:

- Important rejection on 1rst entry