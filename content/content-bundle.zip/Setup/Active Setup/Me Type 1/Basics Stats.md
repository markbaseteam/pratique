### Signal Quality:
0: multiple good signals
1: Pod + Piramide
2: Piramide only
3: 1 bad signal
4: 2 bad signal 
5: worst

### Support Quality:
0: Multiple support with divs
1 good support
2: Some support
3: Box alone
4 Box alone bellow all Baselines

### Taking Profit:
* At low of the wick
* ITP
* Flag
* 1rst baseline
* 1rst confluence of baseline
