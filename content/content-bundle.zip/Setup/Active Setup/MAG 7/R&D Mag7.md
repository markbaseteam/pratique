+[[Mag 7 Setup]]
# R&D MAG7:
Considering that it's one of the setup I know quite well, for the time being, my priority is finding rules for SL and Exit but it will be enough to consider it a lvl1 setup afterwards 
- - -
### R&D Rules:
- If a TP(Flag or ITP) is ignored by the strat, then, he isn't recorded in the table.
- What to do if the is no itp but the strat require one -> but it above the max value
- If you want to do an early Stop: just fill all the cases with the exit price
In the  'Profit and loss' Section,
- if there is a flag before the last itp, he is considered as one
- If there is a red flag, all remaining ITPs and Flags will be buried here
If there isn't a tp signal (ex a 5th ITP or a 2nd Yellow flag), then the price inserted as to be ∞ (above max value)
- If there is no T_STEP: 1.5ATR is used
- Seems like the rule: "ATR SL on Blue/Grey Candle only" is interesting
- Basically it's, -> Very good setup: ATR || Others = 1.5ATR
#### TP:
- Should I consider a 5th ITP as a 2nd Flag? → no
#### Short Adaptation: 
Flags= GPS
Red Flag = Green Square ? / GPS in the baseline?
ITP = ITP genius idea!
#### How to consider the 5th wave or key fib Mag7?
- Idea: Use regular Mag7 TP except the setup's own TP are beyond them.
- 5th Wave-
	- Entry: For the moment, same as Mag7
	- Exit: Determined by the strategy.
- Key Fib Level-
	- Entry:
	- Exit:
#### How to record trades that are enterable with only one SL strat? 
- like a weird signal that I only enter with a 1.5 atr
### Trade Management:
- Heat or Overextended RSI => Strong Trade
#### Strong Trade Trust:
#### Weak Trade Trust
- 3 ITP / in a row (or almost) that are very close -> Early Exit
- 
#### How to deal with an "Overextended" MFI/RSI?
- If strong trade trust:
- If weak trade trust:
	- 3 ITP / in a row (or almost) that are very close -> Early Exit
	- 
- 
### New Cologne:
#### "adaptive strat"
- If rules indicate a "1.5atr or just atr" 
#### Setup Condition
- C-Bet/ ""5th Wave / Wave Key level"" / 
#### Market Condition (Overall trend = tf * 6)
- Against/ Continuation/ Sideway

- - -
#### Lessons learned form R&D:
- For the moment at least, the "feeling" SL seems dead.

- - -
#### Reflexion on taking all profit if price reach major S/R
- On wich Market condition would it be preferable?
	- I see 2, Breakout (Mostly pattern  like a triangle)
##### YES, but it needs to reach the 2nd Major S/R +any Market
An easy one is the 2nd lvl of a Wave Key Level
(The TP is place a bit before the real S/R Box)
- - -
#### Jackrabbit entry
- - - 
#### On Reentry
- The observation is the following, 
I see that on multiple occurrences, the Atr SL gets taken but not the 1.5 and after a few candles, a setup even better than the one before is showing itself.

### Fading
- When blue dot right into thick Arma ribbon: proba of retracing (1 ATR, 1.5)
- + proba of correct signal if conter one
- [[{ Trading Psychology 2.0]]

## C-Bet 

### Questions to answer
- [x] 1. Can you enter if no Baseline reclaim? ✅ 2022-06-23
- [x] 2. What’s the diff if there is some baselines blocking (esp n°: 3) ✅ 2022-06-23
- [x] 3. Is there a diff if the pa is choppy / sideway before printing an entry ✅ 2022-07-27
- [x] 4. Is there a max n° of setups ✅ 2022-06-23
- [x] 5. Where are my TP? ✅ 2022-07-27
- [x] 6. Does it work also when there hasn’t been an arma touch ✅ 2022-07-27
- [x] 7. Is there a diff if the price goes into EQ3 ✅ 2022-06-23
- [x] 8. Is there a diff with the signals (expl: from color shift + C-bar 1 shift+ mom cross to full fledge grey candle + red dot and white diamond) ✅ 2022-06-23
- [x] 9. a diff if there as been a substantial reaction from the last low (or sideway ✅ 2022-07-27
- [x] ☞ if the signal is above baseline and price breaks it 1/2 candle after ✅ 2022-07-27
- [x] if baseline 1 is break + signal but there is a weak ass arma still blocking ✅ 2022-07-27
### Rules from observations
#### Signal Validations
1. Baseline reclaim 
2. Some signal (from color shift + C-bar 1 shift + mom cross to full fledge grey candle + red dot and white diamond
3. The candle mustn’t be to big 
4. The best baseline reclaim will be with base1, arma and base3 + close just after
5. If pa is really clean + went above/bellow a thick eq3, can you consider building a postion even if no signal 
#### Confluence and qualtity
1. Bear Flag / Breaking out of a pattern
2. The further away the signal is from last High/Low the better
#### Stop Loss
- Seems like 1 ATR is great as in case of no quick reaction, to price either doesn’t continue or chop/reverse 
#### Take Profit
 - When not looking to htf and swing logic:
-  TP1: 1.5 ATR  or maybe a 0.382 fib extension
	I would guess between 
In case of really strong trend (like for a 5th Wave reversal setup), you might want to tp with classic Mag7 strat
- no SL to entry with TP1 maybe tp2 or trailling stop with tp2

It seems that it must be traded as an Hybrid except in the cases of *really* strong trend

# Fading 
- big work my boy:
## Question mark ¿
- [x] Is there a particular setup that should make me early exit (expl Green Square) ✅ 2022-07-27
- [x] Is there a diff ✅ 2022-07-27
Early exit when the price doesn’t quickly retake the last low/high
## Study Rules
### General
#### Direction
0: Up
1: Down
#### Time-Frame
5-15-60
#### Timing
0: Very early, price has bounce from base1
1: Just after → bounce from arma
2: thought arma and back
3: Thought arma and to EQ3 then back up
#### Number of valid faded signals
1  - 2 - 3
#### Fib retracement
0.5
0.618
0.786 (counted as such even if slightly frontrunned)
### Take Profits
#### ATR
1 and 1.5
#### Fibs Extensions
0.382
0.5
0.618
0.786
