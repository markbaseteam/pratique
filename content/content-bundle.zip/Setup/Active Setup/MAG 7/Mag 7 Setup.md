[[Trading]]
# Title: MAG 7 Setup
- - -
#### Meta:
- Infos:
	- Type : Entry /  Classic
	- TimeFrame: 15min+
	- Asset: Crypto + Forex
	- Direction: Any
## ⚠︎ MOST IMPORTANT MAG7 RULE  ⚠︎
- **ALWAYS** check if you are caught in a **pattern** or **range**!
- Same goes for or a very htf arma ribbon 

→ If you want to play the breakout
1. Needs confluence
2. Be really careful of any potential div that will fuck you up
3. 1.5 Atr + Low risk
4. The best will always be to try creating a position on the range edge with either simple limit orders or faded signals
5. Remember to *always* take profits at the edge of a pattern

→ Even Better = Wait for a retest and confirmation
1. Depending on the situation you could even enter 1 ATR SL and 2x risk
2. Just wait for a *proper* retest and continuation signals!
3. 
## 📋  Theory / Basic Concept
![[Mag_7_Long_Setup-v3.png]]
![[Mag_7_Short_Setup-v3.png]]
#### Key Notes:
- If used as a Trend Reversal, cf [[Theory Wave Key Level]]
- Important confluence is the Arma ribbon cf Edgewonk Stats, the thicker and the most inclined in the same trend the better.  
## 🕹 Practice:
### Temporary Rules Mag 7
- Stop-Loss: 1.5 ATR or 1 when TOP setup (2nd great entry after a valid 1.5ATR one)

#### What is a perfect entry?
- Simples rules:
	The more baselines reclaimed, the better
	The closer from bs1 the close is the better
	Big momentum wave or divergence? → Even better
	Recent failed opposite direction signal? → good
- There was an early signal whose 1.5 ATR SL wasn’t taken out
	→ Money Maker baby → 1 ATR + Highest risk you Money management allows 
- You still have to play a bit with E3 (maybe of higher tf)
	→ 1.5ATR

- Lol actually my sample for studie was wrong so now the 1.5ATR doesn’t appear a lot more interesting 
- - -
- Take Profit: 
	- -1st and 2nd Flag- or -1st and 2nd GPS/Green Square- 
	- 3rd ITP
	- 33.3% for each
### Stats and Money Management:
#### Money/Risk Management=

### The Entry: (Perfect examples)
#### 1st Type: (C-Bet)
- 15 min the 06/06/2022
#### 2nd Type: (Trend Reversal a.k.a Bluff)
- How do we determine if it's the end of a trend?
	1. Rejection from key level (Fib/Volume/BFN/DSR)
	2. Continuation Failure (Usually a c-bet Mag 7 that crash into divs)
	3. Failure of 'all' mas (Mag7)
	4. Best Trend reversal are generally Higher TF C-Bet 
#### Worst Allowed Entry:
### The Exit:
#### Basics Rules:
#### What signals to ignore:
- any signals that where the price hasn’t even cross the 1:1 of RRR
So if you are counting ITP, your count only start after
- You can also ignore them if you consider there is a pullback (Needs _Strong_ HTF Confluence )
#### Hybrid Setup:
- AKA: in witch case is it more advantageous to limit sell your mag7:
1. When going against the arma of an htf
	1. If First test → closest part of the ribbon
	2. I 
2. When a thick EQ3 is against us.
	- TP should over around the green ma (the furtherest one)

### The Management:
#### Early Exit:
##### Divs on entry:
- If the entry is on a forming div of the momentum (Div need to be pretty strong or/with a Week/Odd Mag7 )
- Exit is made on the 1st ITP (Min 60%)  Needs to be quantified 

#### 2nd and 3rd Barrel:
##### Adding to a loser:
##### Adding to a winner:
- For simplicity purpose, the "new trade" as an ATR SL
### TimeFrame rules:
- The shorter the TF, the better the signal must be
- Especially in the case Trend reversal
	- With a strong 4h Trend, you can min except the first 10 15min Mag 7 to crash in is rubban
#### Observation on the 15-5min:
- It’s very important that the signal candle close after baseline 1, otherwise good opportunity  to counter trade
# Footnote:
- - -
+Linked Pages:
[[Notes Mag 7|Notes]] List of Legit Trades Pictures
+[[R&D Mag7]]
#trading/setups
Setup Type:: Active