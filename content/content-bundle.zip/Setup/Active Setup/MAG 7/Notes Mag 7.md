+[[R&D Mag7]]
+[[Mag 7 Setup]]
* A confluence key point could be a quick spike before the signal


## Important Tasks:
- [x] ATR SL VS 1.5ATR (when which ?) ✅ 2022-07-27
- [x] Take profit: which TF and Levels VS Momentum? ✅ 2022-07-27
- [x] When there is a 2nd Mag7 even tho the 1st one still hasn’t ben ✅ 2022-07-27
## Setups:
### C-Bet:
- A few rules are key here:
There is the need of a **STRONG** trend on the higher TF, a C-BET much more than the _Reversal Setup_ needs the incentive of the HTF
Probably even on a HTF^2 (eg: 15min signal, 1h Trend Strength, 4h not blocking)
- Another great trick: you check the highest TF that has produced a valid MAG7, you know you can C-BET until his 1st TP  (eg: from 18 → 28 Mars on D)
	-  bearish break of market structure (HH LL)
- Higher Time Frame C-Dot!
#### Validation of entry
- Don’t forget your basics!
	You should always be looking for classic PA patterns
	so if you see the break of a bear flag with a mag7 C-Bet => Money printing
- Usually the C-Dot must be before the Blue Dot but it can be ok if the 5min also have a mag7
- 
#### Perfect exemples
![[BTCUSD_2022-06-11_16-02-38_45196.png]]
## Stop-Loss:
#### C-Bet:
- Perfect signal => Aggressive SL
![[BTCUSD_2022-03-29_13-21-37.png]]
#### Reversal:

#### Breakout:
- Of pattern => 1.5 (except if Pullback Done)
- Of Trend => Depends 
#### Fading:
When the Baseline 3 is blocking → ATR 


## Taking Profits:
#### C-Bet:
##### 1st TP:
2 possibilities comes to us
1. Price goes through the roof => TP at Yellow Flag (that or 10% each ITP) _CF:1_
2. Price isn't very responsive, 
#### Reversal:
##### 1st TP:
Seems like a good 1st tp would be at the first signs of Green Square and MFI bottom
Also seems to correspond to a mini AB/CD
Conservatory approach would be 0.786 in fib extension 


- - -

#### Early TAKE PROFITS with Big Levels (VAs, Pocs, ext)
##### Observations:
- Needs to have been at least 1 ITP
##### What level?

##### What is the reaction from this level?


## Misc
- - -
### Adding to position / Late Entry
#### Observations:
When There is a strong trend,
You are looking to add at the retest of Baseline 1-2
#### Possibilities:
Blue dot
or LTF Dragon Bone
LTF C-Bet obviously 

- Best scenario is main tf retest bs 1-2 and LTF prints a dragon bone 
### Retest of breakout with colour shift entry
- The observation is the following, 
I see that on multiple occurrences, the Atr SL gets taken but not the 1.5 and after a few candles, a setup even better than the one before is showing itself.
#### Reentry in Eliott's color shift
- Exemples:
	- ![[Second Entry Short.png]]
##### Observations:
- Need to break 2 baselines
- No Important opposite signal (any+ above simple mom cross )
	- @
	- The first candle mustn't break all baselines -> otherwise it could be interpreted a "true" fake-out 
- --
### Mag 5
- Still important to have both C-Bar in agreement 

### 15min observations:
- Absolute need of limit fixed tp TP, at least for 1 (Only when Hybrid setup)
- only exception is if you basically use it as an entry for a 1h MAG7
But otherwise in choppy of uncertain environment it is a necessity 
If strong trade trust, then TP at first strong S/R
depending on trade trust, tp between 30%-60%
- Really needs Clear signals (and perfect ones when conter trading an htf)

### MSX8:
- look for the width of 4h momentum`
### ENTRY Against the Arma ribbon:
- Finnaly! I have understood what differ when going against the arma ribbon
the C-bar!
- When you go against an 1h ribbon, you are looking for an entry on the 15min
- to confirm your entry you will need the C-bar of the 1h
To be more precise it goes like this:
1. The 1h try to reverse with a wrong mag7 (Crash in the ribbon)
2. Reaction that can do a 1-1.5 ATR and reach Baseline 1
3. The 15’ shows reaction 
	1. Can be Green Square, Liquidations, Wicks on SFP, etc
4. It’s even better if the 1h also shows a great reaction
	1. Such as a Hammer Candle for expl
5. Now the 15’ is printing A nice Mag7
6. And the most important factor in all of this is that since the 1st Step, the 1h has kept is C-BAR confirmations!

# Fading Rules
## R&D Tasks:
- [x] ⚠︎ ☞ Blue Dot VS Single C-Bar VS Long C-Bar + single Short C-Bar ✅ 2022-07-27
- [ ] Fib Extension as take-profits
- Simple idea: if entry at 0.5fib → Exit at 0.618 ext
- [x] The case of Red/Grey Candle with only one c-bar → need to test for 1.5 atr SL ✅ 2022-07-28
- [x] When it’s the second/third correct Fade signal? ✅ 2022-07-27
- [x] Is there a diff if mom is above 0 or printing divs ✅ 2022-07-27
## Notes
Be careful of 5th wave Setups
Better wait an entry on the next candle if not 100% confident (next candle or footprint absorption ect)
- A bull Divergence doesn’t invalidate a bear setup
- Red/grey candle are bad candidate for bear (trend) setups + seems like there are always a bit far from Bs 1+3 and have only the fast c-bar
### Incorrect C-BET:
- 2 different scenarios
1. the signal is at the very end of the trend
2. Price has already made a retracement bellow arma ribbon
#### In case of Mag5
Need more observations but selling on a grey candle seems having lower winrate
##### Hard no:
HTF as printed a c-dot

### Almost correct C-BET
1. Watch for the HTF Wave:
	Is it going in the opposite direction? Or maybe showing great weakness?
2. Were you expecting a follow-up here? Does it makes sense / is it some sexy price action?
3. Look at the Momentum, Is there some big gap that would irremediably create a div?
If it’s like half odd half, logic PA but you have diverging momentum on both TF → Wait for 1 candle or enter on the first opposite direction candle
![[BTCUSD_2022-06-20_12-57-38_0600f.png]]
![[BTCUSD_2022-06-20_13-19-21_9f03f.png]]
#### TAKE PROFITS ?
1st Tp should target the greater RRR between Arma ribbon/1.5ATR
#### Insights on entry
From what I have seen, in the peculiar type of setup, yes you can wait for the next candle but an even better approach would be: Prepare you entry and pull the trigger as soon as you see Absorption or other pattern on the LTF
- [x] ☞ I just need to check if you go with the HTF SL or the LTF’s one ✅ 2022-07-28




# Question Pool:
- Can you consider fading a C-Bet Mag7 even it’s breaking all Baselines if your going against a *huge* resistance + HTF Wave hasn’t crossed
	From 1 observation (lol) and logic, I would say Yes if you also have like a mom div 
	I would even go as far as to say that as long as it feels “odd” + mom div then fade me that baby!

### On fading a Mag7 C-Bet when no mag7:
1. When strong div + confluence ect you can enter on a ‘no blue dot but still both c-bar signal’
2. If no both c-bar → you can enter on a rejection of the baseline 1 with  some absorption on the footprint + maybe a “trapped c-dot”