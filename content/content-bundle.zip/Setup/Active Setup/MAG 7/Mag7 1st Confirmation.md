# Title: Mag7 1st Confirmation
- - -
>[!toc]
>[/TOC/]

> [!info] Meta
> - Type : Entry /  Classic
> - TimeFrame:
> - Asset:
> - Direction:
> - Tags: #9/Theory  #5/mag7 #0/moc 
> - Type::

- - -

## 📋  Theory
- How to enter on the 6 point
![[ES1!_2022-10-17_22-27-53_428f9.png]]
#### Key Notes:
1. Strong Mag7 signal that you should be able to decompose correctly
### Special Entry without a Bullish candle→
		![[BTCUSDTPERP_2022-11-02_15-46-23_30172.png]]
	 ![[ETHUSD_2022-11-02_15-46-05_73bbe.png]]
- - -
- Note That SL Should be wider if there is still an FVG created by the mag7:
# to r&d
- [ ] Can you enter when the candle is red (bear)
- [ ] Should you rather enter on the confirmation (or add / move SL)
- [ ] Does both c-bar needs to be still grey




## 🕹 Practice:
### The Entry:
#### 1st Type:
#### 2nd Type:

### The Exit:
#### 1st Type:

### The Management:
#### 1st Script:
