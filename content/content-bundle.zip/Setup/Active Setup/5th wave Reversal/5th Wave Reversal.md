[[Trading]]
# Théorie:
We start with a classic AB/CD and predict a shift of trend when the massive Div appear on the 5th Wave.
![[cb5a2a16d3addd27248f2e1ed87c8bfd.png]]

#### Key Notes:

- The 2nd Wave prints a 0.5 retracement wich can then justifie a small 4th Wave.

# How To Trade It?:

## The Entry:

##### 1rst:
![[Div Between (3) and (5).png]]
##### 2nd:
![[aa4550b17c0b6c24f04c62be08d2287b.png]]
- Drawing a red Sell box in the div area and look for entry in a lower TF
- Expl: Mom Failure / Breakout / Ladder Entry / etc...
- PS: In this exemple, there is the same setup in the setup
##### 3rd:
![[Flash Crash From Top.png]]
* On a lower TF, we see a massive rejection of our previous Red Box.
* We can for expl try to sell the retest of this area
* Or in this exemple, we se a classic setup at the end of trends 1: Big Sell Off, 2: sideway, 3: Rejection at 0.5fib
* We can think here of a ladder from 0.5to 0.618 which also correspond with PA S/R level
* For The SL: Hard to spot in this case, that's why a Signal on low TF could have given the best RRR but otherwise, maybe 0.718fib or a previous High



- - -
+Linked Pages:
[[Notes 5th Wave reversal|Note]]
[[Take-porfit]]
#trading/setups 
Setup Type:: Active

