- As the setup
- The First retracement can't be more than 0.618
- The Div at the end is really important, that's why a (4) can't be to long

### Things to record for the stats:

- retracement values
- Validation of AB=CD
- 5th Wave below Baseline 1 TEMA
## Entry Possibilities:
1. Div Catcher
2. 

- - -
## R&D:
#### First Simple Model:
- For the TP, I take the boxes 

### Goals of calc sheet:
- Determine rules of TP 
### Ways of TP:
- Key level Fib
- Setup Fibs
	- Drawing boxes and ether TP at the top or bottom? 
### Differentiating the Setup:
1. Trend Direction: (Continuation of Larger trend/ Reversal)
2. Setup Retracement
3. Setup Qualitative Note