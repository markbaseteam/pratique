# 1rst Scénario:
- (2) = {0.5-0.618}  **important**
- (4) < 0.5              **small**
### 1rst TP:
- 0.5 fib of (3)
### 2nd TP:
- 0.618 fib of (0)-(5)
# 2nd Scénario:
- (2) < 0.5              **small**
- (4) = {0.5-0.618} **important**
### 1rst TP:
- 0.5 fib of \[0-3\]
### 2nd TP:
- 0.618 fib of \[0-3\]
# 3rd Scénario:
- (2) < 0.5 **small**
- (4) < 0.5 **small**
### 1rst TP:
- 0.382 fib of \[0-3\]
### 2nd TP:
- 0.618 fib of \[0-3\]
# 4th Scénario:
- (2) < 0.382  **Very small**
- (4) < 0.5 **small**
### 1rst TP:
- 0.5 fib of (3)
### 2nd TP:
- 0.618 fib of \[0-3\]
# 5th Scénario:
- (2) = {0.5-0.618} **important**
- (4) = {0.5-0.618} **important**
### 1rst TP:
- 0.618 fib of \[0-3\]
### 2nd TP:
- maybe (0)
# Notes:
* seems like the best 1rst Tp is the lowest retracement of a cluster between [0-3] and (3) Fibs
	* The Only exception is if a 0.5Fib is in the cluster as it should be then preoritize
* 2nd one is the logic but arround the 0.618 Fib
