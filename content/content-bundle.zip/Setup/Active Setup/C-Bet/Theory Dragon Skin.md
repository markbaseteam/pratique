# Title: Theory Dragon Skin
- - -

>[!toc]
>[/TOC/]


> [!info] Meta
> - Type : Classic
> - TimeFrame: 15min+
> - Asset: Any
> - Direction: Any
> - Type:: #9/Theory #0/moc/entry_setup

- - -
- Observations:
	- When the dragon skin is thick, the price tends to continue on it's first reversal attempts
- Use Cases:
	- Adding to a position
	* Late Entry in an emerging trend

# Ideas dump:
### What are the diff areas of Support/Resistance
1. EQ1 (Bs1-2)
2. Arma RIbbon
3. EQ3
4. HTF 
### What kind of signal would you expect from each zone 
#### EQ1 (Bs1-2) -
- Nah, Look for LTF Arma ribbon bounce
##### Take Profit? 
- Except if you have really strong trend conviction → go for LTF 1.5 TP
in any case you can have a 70-80% TP at it and then play the ltf c-bet if any.

#### Arma Ribbon -
##### Uptrend ↗ 
1. Odd Mag7 Reversal
2. Green Square 
3. HTF C-Dot
4. maybe mom divs
##### Downtrend ↘
#### EQ3 - 
##### Uptrend ↗ 
##### Downtrend ↘
#### HTF ARma - 
##### Uptrend ↗ 
1. Odd Mag7 Reversal
2. Green Square 
3. HTF C-Dot
4. maybe mom divs
##### Downtrend ↘




# Dragon Skin
- - -
## 📋  Theory
- Basically the Ideas is to fade LTF reversal attempts into Strong HTF Support/Resistance 

## 🕹 Practice:
### The Entry:
#### In Uptrend
- White Diamond
- Red Diamond
- Blue Dot 
- Pyramid 
- Green Square? 

### The Exit:
#### 1st Type:

### The Management:
#### 1st Script:



- - -
# Dragon Bones
## 📋  Theory
- Basically the Ideas is to fade LTF reversal attempts into Strong HTF Support/Resistance 

## 🕹 Practice:
### The Entry:
#### In Uptrend
- White Diamond
- Red Diamond
- Blue Dot 
- Pyramid 
- Green Square? 

### The Exit:
#### 1st Type:

### The Management:
#### 1st Script:

- - -
+[[Notes Dragon Bones]]
+[[R&D Dragon Skin]]

# Exemples
- - -
## List of situations with a Dragon Skin Setup
```dataview
TABLE
situation-1 AS "Situation 1",
situation-2 AS "2",
situation-3 AS "3",
situation-4 AS "4",
situation-5 AS "5"
FROM #5/dragon_skin  and #2 
```
## List of standalone MAAS setup
```dataview
list
FROM #setup/maas and !#sit and outgoing([[]])
```
