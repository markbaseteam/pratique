# Notes Dragon Skin and Bones Setup
## Checklist Ideas
- LTF sttf to strong to allow 1st touch (maybe C-Bet opposite trend)
- Max N° of trades in a row (prob 2)
- n° of candles since last high 
- Proximity with BS1-2 and ribbon
- Need bs2 to be flat
- No Clear continuation fail

## todo
- An “extreme bullish environement” setup (with G-C yellow flags)
## Observations
#### For a 1h/15' D-B/D-S
5’ Green square → 2-3 with some local sfp work amazing (it used to be the footprint+ltf mag5)



- - -
# Trash
### General:
- Possible scenarios:
	- Trend Retracement
	- Ranges
	- Small Dump Before Mag7
- - -
## Ranges:
#### Entry:
- 1st Itp with SL at xATR
- Add on 3rd signal with SL at ATR 
#### Exit:
- 50ema
- ATR
- xATR
- 1st/2nd LTF ITP
- 1st ITP
- Open of the candle that jumped out (Bart)
- POC of the range
- Middle of the range
- --
## Dragon Bones:
- We could consider to have 2 setups here, one when the price close outside of the ribbon 
- Or maybe just, Beginning of a trend or not / like x attempt of reversal 
#### Entry:
#### Exit:
- ATR
- xATR
- - -
- -  -
### The Entry:
- SL ATR / 1.5 ATR
- 1st entry = 1.5 ATR, 2nd/ADD = ATR
- Sl on the furtherest/closer 1.5 ATR 
#### Adding:
- Sl on the Wick? 
### The Exit:
- TP ATR / 1.5 ATR
- ITP of Lower TimeFrame
- Sl on the furtherest/closer ATR
### Ranges:
#### Entry:
- 50ema
- ATR
- xATR
- 1st/2nd LTF ITP
- 1st ITP
#### Exit:

### The Management:
 -- - 
### Misc:
#### RRR And winrate
If SL=1.5ATR and TP=ATR => 0.65 RRR => min 62%Winrate
-> min 75%Winrate
- If RRR = 1 => min55% (fees) =>min60%
- - -
### Ideas dump:
Test for anytime there is 3 close ITP in a row
Overall Market Setup:

Reversal
Sideway
Continuation

We Could differentiate 2  scenarios for the TP:
- 1: We trust the Trade Direction
	- Expl: 40-50% TP at first resistance
- 2: We are in the Dark
	- Expl: 90-100% TP at first resistance


- When the pa isn’t good enough and could require a second touch, might be possible to go around it if BTC is OK and ETH has already made is 2nd one