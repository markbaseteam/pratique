[[Trading]]
#### Théorie:
* Un C-bet est un trade qui parie la continuation de la trend et donc la création de new low/highs
* Il peut cependant être justifié de le stopper plus tôt

#### Types of C-Bet:
* Dragon Skin
* Punchout
* Flag
* 001
- - - 
- - -
# Dragon Skin: [[Theory Dragon Skin]]
#### Goal:
* Bet on the continuation of an emerging trend.
* This setup is manly thought for two situation:
	* Adding to a position
		* Late Entry in an emerging trend

- - -
- - - 
# Setup Top Sell-Off: (Pure BTCUSD setup)
#### Goal:
* Bet on the continuation of a reversal that have crash from the previous big trend with a very sharp move.

#### Localisation: 
* Expected localisation is between 0.5 and 0.618 fib

#### Entry Methode:
* SFP
* Boxer
* Mom weakening
* Breakout 
* Mag7