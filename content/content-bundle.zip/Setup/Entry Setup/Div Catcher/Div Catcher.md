[[Trading]]
# Title: Div Catcher
- - -
#trading/setups 
[type::Entry]
#### Meta:
- Infos:
	- Type : Entry
	- TimeFrame:
	- Asset:
	- Direction:
- Observations:
	-  As it's name implies, the main goal of this setup is to catch forming divs.
	- It will do so by drawing a box below/above a previous low/high in order to be filled with the forming div.
## Théorie:
![[BTCUSD_2022-03-26_18-49-38.png]]
![[BTCUSD_2022-03-26_18-50-17.png]]
- (0) is put at the beginning of the recent trend, not the whole wave.
	- Look at how it perfectly correspond to the last GPS and proper Mag7
#### Key Notes:
- Box VS SL:
	- From Observation, I would go 50/50 on crypto and of course SL on Forex.
- Tight VS Loose SL:
	- Observation seems to encourage Tight SL but make sure to catch the bus if the price pierce through but still reverse. (Entry on a Mag5 or 7)
### 2nd Barrel
#### In a short scenario
- Red flag
- Eventually a simple Red candle
##### Moving the SL 
- It doesn’t really makes sense for me to move the SL as the setup is already that strong and that it might (*will*) takes some time to play out
#### In a long
- Green Square / GPS 