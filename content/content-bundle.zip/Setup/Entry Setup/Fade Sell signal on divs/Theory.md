#### Steps:
1. Visible bounce from a logical Support + Pattern/Wave Objectif
2. Attempt to continue with  a sell signal 
3. The mom has already made a
# Title: Fade Sell signal on divs
- - -
#### Meta:
- Infos:
	- Type : Entry /  Classic
	- TimeFrame:
	- Asset:
	- Direction:
- Observations:
	- 
## Théorie:
#### Key Notes:

## Practice:
### The Entry:
#### 1st Type:
#### 2nd Type:

### The Exit:
#### 1st Type:

### The Management:
#### 1st Script:
